# Hisab — iPhone Prototype

This is a mobile-friendly working prototype of a Credit/Debit ledger.

Features:
- Credit (Jama) and Debit (Kharcha)
- Party-wise balances
- Dashboard totals
- Transaction history
- Reports
- CSV export
- Local device storage (localStorage)

Open `index.html` in Safari on iPhone. For a true App Store app, the same screens can be converted to SwiftUI/Xcode and connected to iCloud/Face ID.
